<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/opt/lampp/htdocs/elbrus/wp-content/plugins/wp-super-cache/' );
define( 'DB_NAME', 'elbrus' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'admin' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', 'root' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );
define( 'FS_METHOD', 'direct');

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'TTME6<]41w`K@Oi::nqvFPo?F287 a&zZkWl>lbZP[m/W,r/@u~$!6p]<S;!*|J{' );
define( 'SECURE_AUTH_KEY',  'k{Pw]{2qH%9EZiX8c;||@Isp&x/Q=<#;5T:s^6a3-0H9*iT+TNb>ROW;@^;3:&Pb' );
define( 'LOGGED_IN_KEY',    'T-?5%H].= D+^P?5{q`6><yU&&Pa:GMuiVr?xFK5}ztxaZGA|e],:@!`T7BCe:+l' );
define( 'NONCE_KEY',        'Ov.=@JC(;x&lBI6L&f oeIUivW6Q7_roFf/}-J0|F4PN1P[<S,nJQzQ)2ZVGCMf}' );
define( 'AUTH_SALT',        'pT=qlvH?Ht}fw)(0b|:4R;3XvXWs{Wr3JNV+hYK7=HFVrgu%FFio:nu`BsE88RlC' );
define( 'SECURE_AUTH_SALT', 'qhXc)nbfX-~%fZb)]QebTOxLSqP<-Rb)#TF<oXg`{YKf?omQyGz,W;?C8U0xTv2@' );
define( 'LOGGED_IN_SALT',   'D7B]@6ZD|+3Qab+>0fLREw7g^?R38a#cBnW[IJxHm}.ro8J{ia#++04.MGP#E-XR' );
define( 'NONCE_SALT',       'm!Zdto[>Ja1></kCo0O}~o}+}YeH-$G1NtOv!,H_Xf8-%xq>~rC4:{Gg`F0E.hj>' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
